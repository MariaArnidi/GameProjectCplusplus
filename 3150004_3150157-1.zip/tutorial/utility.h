#pragma once

float rand0to1();

struct Disk
{
	float cx, cy;
	float radius;
};