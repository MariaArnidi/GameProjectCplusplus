#include "utility.h"
#include <random>

float rand0to1()
{
return rand() / (float)RAND_MAX;
}